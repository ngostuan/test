from flask import Flask,  render_template, jsonify, request, Response
import logs
from modules.hadoop import Hadoop
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/hd2')
def hd2():
    return render_template('hd2.html')

@app.route('/hd3')
def hd3():
    return render_template('hd3.html')
@app.route('/run_checks', methods=['POST'])
def run_checks():

    hadoop_checker = Hadoop("examples")  

    results = []


    def custom_logger(message):
        results.append(message)

  
    logs.INFO = custom_logger
    logs.ERROR = custom_logger
    logs.DEBUG = custom_logger
    logs.ISSUE = custom_logger
    logs.RECOMMENDATION = custom_logger

   
    hadoop_checker.check_conf()
    

    return jsonify(results=results)

def generate(command):
    try:
        # Thực thi lệnh với subprocess
        process = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )

        # Đọc stdout và gửi kết quả từng dòng qua SSE
        for line in iter(process.stdout.readline, ''):
            yield f"data: {line}\n\n"  # Trả về dòng dữ liệu

        # Đọc stderr (nếu có) và gửi lỗi
        for line in iter(process.stderr.readline, ''):
            yield f"data: {line}\n\n"  # Trả về lỗi nếu có

        process.stdout.close()
        process.stderr.close()
        process.wait()

    except Exception as e:
        yield f"data: Error: {str(e)}\n\n"

@app.route('/run_command', methods=['GET'])
def run_command():
    # Lấy lệnh từ query parameters
    command_map = {
        'cat_file1': 'cat 336.txt',
        'cat_file2': 'cat file2.txt',
        'cat_file3': 'cat file3.txt',
        'run_script': 'bash ../Hadoop3/start.sh'
    }

    command = request.args.get('command')
    
    if command not in command_map:
        return Response("Invalid command", status=400)

    # Sử dụng SSE (Server-Sent Events) để gửi dữ liệu liên tục
    return Response(generate(command_map[command]), content_type='text/event-stream')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
