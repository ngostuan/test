
tshark -a duration:10 | hadoop fs -put - /tshark38
hadoop jar /usr/local/hadoop/etc/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.3.6.jar -mapper ./mapper.py -reducer ./reducer.py -input /tsharkf -output /user/outputf
for i in {1..2}
    do
        tshark -a duration:10 | hadoop fs -put -f - /tshark1
        hadoop fs -cat /tshark1 | hadoop fs -appendToFile - /tsharkf

        hadoop jar /usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.3.6.jar -mapper ./mapper.py -reducer ./reducer.py -input /tshark1 -output /user/output1
        hadoop fs -cat /user/output1/part-00000 | hadoop fs -appendToFile - /user/outputf/part-00000
        hadoop fs -rmr /user/output1
    done