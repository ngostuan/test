#!/bin/bash  
sudo tshark -a duration:10 | hadoop fs -put - /tshark38
sudo /usr/local/hadoop/bin/hadoop jar /usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming.jar -mapper ./mapper.py -reducer ./reducer.py -input /tsharkf -output /user/outputf
for i in {1..2}
    do
        sudo tshark -a duration:10 | hadoop fs -put -f - /tshark1
        sudo /usr/local/hadoop/bin/hadoop fs -cat /tshark1 | hadoop fs -appendToFile - /tsharkf

        sudo /usr/local/hadoop/bin/hadoop jar /usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming.jar -mapper ./mapper.py -reducer ./reducer.py -input /tshark1 -output /user/output1
        sudo /usr/local/hadoop/bin/hadoop fs -cat /user/output1/part-00000 | hadoop fs -appendToFile - /user/outputf/part-00000
        sudo /usr/local/hadoop/bin/hadoop fs -rmr /user/output1
    done