#!/bin/bash

semgrep --version &> /dev/null

if [ $? -eq 0 ]; then
    echo "Semgrep đã được cài đặt."
else
    echo "Semgrep chưa được cài đặt. Đang cài đặt..."
    python3 -m pip install semgrep

   
    if [ $? -eq 0 ]; then
        echo "Cài đặt semgrep thành công."
    else
        echo "Cài đặt semgrep thất bại. Vui lòng kiểm tra lại."
        exit 1
    fi
fi


HADOOP_VERSION=$(/usr/local/hadoop/bin/hadoop version | grep "Hadoop" | awk '{print $2}')
echo "Phiên bản Hadoop: $HADOOP_VERSION"


URL="https://github.com/apache/hadoop/archive/refs/tags/rel/release-${HADOOP_VERSION}.zip"
echo "Đang tải xuống từ: $URL"


wget "$URL" -O "release-${HADOOP_VERSION}.zip" -q


if [ $? -ne 0 ]; then
    echo "Tải xuống thất bại. Vui lòng kiểm tra lại."
    exit 1
fi


echo "Đang giải nén release-${HADOOP_VERSION}.zip..."
unzip -q -o "release-${HADOOP_VERSION}.zip"


if [ $? -ne 0 ]; then
    echo "Giải nén thất bại. Vui lòng kiểm tra lại."
    exit 1
fi


echo "Đang quét thư mục hadoop-release-${HADOOP_VERSION} với semgrep..."
semgrep scan "hadoop-rel-release-${HADOOP_VERSION}"


if [ $? -eq 0 ]; then
    echo "Quá trình quét thành công."
else
    echo "Quá trình quét thất bại. Vui lòng kiểm tra lại."
    exit 1
fi
